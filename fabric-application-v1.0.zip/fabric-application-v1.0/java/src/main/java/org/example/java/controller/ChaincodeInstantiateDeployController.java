package org.example.java.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ChaincodeInstantiateDeployController {

    @RequestMapping("/chaincodeinstantiate")
    public String chaincodeInstantiate(){
        return "";
    }
}
