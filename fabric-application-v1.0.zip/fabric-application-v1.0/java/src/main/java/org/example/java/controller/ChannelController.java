package org.example.java.controller;

import org.example.java.chaincode.invocation.InvokeChaincode;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.network.CreateChannel;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

@Controller
public class ChannelController {

    String str_create_channel="创建失败";
    @RequestMapping("/channel")
    public String channelCreate(){
        try {
            //密码授权
            CryptoSuite.Factory.getCryptoSuite();
            Util.cleanUp();
            // Construct Channel
            //赋予用户上下文信息
            UserContext org1Admin = new UserContext();
            //注册组织1
            //读取配置文件信息
            File pkFolder1 = new File(Config.ORG1_USR_ADMIN_PK);
            File[] pkFiles1 = pkFolder1.listFiles();
            File certFolder1 = new File(Config.ORG1_USR_ADMIN_CERT);
            File[] certFiles1 = certFolder1.listFiles();

            Enrollment enrollOrg1Admin = Util.getEnrollment(Config.ORG1_USR_ADMIN_PK, pkFiles1[0].getName(),
                    Config.ORG1_USR_ADMIN_CERT, certFiles1[0].getName());
            org1Admin.setEnrollment(enrollOrg1Admin);
            org1Admin.setMspId(Config.ORG1_MSP);
            org1Admin.setName(Config.ADMIN);

            //注册组织2
            //读取配置文件信息
            UserContext org2Admin = new UserContext();
            File pkFolder2 = new File(Config.ORG2_USR_ADMIN_PK);
            File[] pkFiles2 = pkFolder2.listFiles();
            File certFolder2 = new File(Config.ORG2_USR_ADMIN_CERT);
            File[] certFiles2 = certFolder2.listFiles();
            Enrollment enrollOrg2Admin = Util.getEnrollment(Config.ORG2_USR_ADMIN_PK, pkFiles2[0].getName(),
                    Config.ORG2_USR_ADMIN_CERT, certFiles2[0].getName());
            org2Admin.setEnrollment(enrollOrg2Admin);
            org2Admin.setMspId(Config.ORG2_MSP);
            org2Admin.setName(Config.ADMIN);

            FabricClient fabClient = new FabricClient(org1Admin);

            // Create a new channel
            //创建通道
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            ChannelConfiguration channelConfiguration = new ChannelConfiguration(new File(Config.CHANNEL_CONFIG_PATH));

            byte[] channelConfigurationSignatures = fabClient.getInstance()
                    .getChannelConfigurationSignature(channelConfiguration, org1Admin);

            //通道实例
            Channel mychannel = fabClient.getInstance().newChannel(Config.CHANNEL_NAME, orderer, channelConfiguration,
                    channelConfigurationSignatures);

            //创建节点实例
            Peer peer0_org1 = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            Peer peer1_org1 = fabClient.getInstance().newPeer(Config.ORG1_PEER_1, Config.ORG1_PEER_1_URL);
            Peer peer0_org2 = fabClient.getInstance().newPeer(Config.ORG2_PEER_0, Config.ORG2_PEER_0_URL);
            Peer peer1_org2 = fabClient.getInstance().newPeer(Config.ORG2_PEER_1, Config.ORG2_PEER_1_URL);

            //节点加入通道
            mychannel.joinPeer(peer0_org1);
            mychannel.joinPeer(peer1_org1);

            mychannel.addOrderer(orderer);

            if(!mychannel.isInitialized()){
                mychannel.initialize();
            }

            fabClient.getInstance().setUserContext(org2Admin);
            mychannel = fabClient.getInstance().getChannel("mychannel");
            mychannel.joinPeer(peer0_org2);
            mychannel.joinPeer(peer1_org2);

            Logger.getLogger(CreateChannel.class.getName()).log(Level.INFO, "Channel created "+mychannel.getName());
            Collection peers = mychannel.getPeers();
            Iterator peerIter = peers.iterator();
            while (peerIter.hasNext())
            {
                Peer pr = (Peer) peerIter.next();
                Logger.getLogger(CreateChannel.class.getName()).log(Level.INFO,pr.getName()+ " at " + pr.getUrl());
            }
            if(mychannel.isInitialized()||mychannel.queryBlockchainInfo()!=null){
                str_create_channel="创建成功";
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_create_channel.toString().equals("创建失败")){
            return "success" ;
        }else{
            return "error";
        }

    }

    @RequestMapping("/querychannel")
    public String channelinfoquery(){
        return "success";
    }

    @RequestMapping("/queryblockbynum")
    public String queryblockbynum(){
        return "success";
    }

    @RequestMapping("/queryblockbyid")
    public String queryblockbyid(){
        return "success";
    }

    @RequestMapping("/querychannelstate")
    public String querychannelstate(){
        return "success";
    }

    @RequestMapping("/isinvokesuccess")
    public String isinvokesuccess(){
        return "success";
    }
}
