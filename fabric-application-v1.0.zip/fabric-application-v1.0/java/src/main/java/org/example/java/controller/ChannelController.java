package org.example.java.controller;

import org.example.java.chaincode.invocation.InvokeChaincode;
import org.example.java.network.CreateChannel;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ChannelController {

    @RequestMapping("/channel")
    public String channelCreate(){
        return ""+ CreateChannel.createchannel();
    }

    @RequestMapping("/querychannel")
    public String channelinfoquery(){
        return "";
    }

    @RequestMapping("/queryblockbynum")
    public String queryblockbynum(){
        return "";
    }

    @RequestMapping("/queryblockbyid")
    public String queryblockbyid(){
        return "";
    }

    @RequestMapping("/querychannelstate")
    public String querychannelstate(){
        return "";
    }

    @RequestMapping("/isinvokesuccess")
    public String isinvokesuccess(){
        return InvokeChaincode.invokechaincode();
    }
}
