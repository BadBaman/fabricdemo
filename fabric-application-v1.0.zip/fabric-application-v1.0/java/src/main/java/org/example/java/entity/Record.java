package org.example.java.entity;

import java.util.Objects;

public class Record {
    private String Applicant;
    private String Notice;
    private String Noticetime;
    private String Confirmor;
    private String Confirmtime;
    private String Omicsoriginalresultprovider;
    private String Omicsoriginalapplicationreceivedtime;
    private String Omicsanalysisresultprovider;
    private String Omicsapplicationreceivedtime;
    private String Phenotypicdataprovider;
    private String Phenotypicapplicationreceivedtime;
    private String Datadeliverytime;
    private String Datadeliverymethod;
    private String Deliverer;
    private String Deliverercontactinformation;

    public Record(String applicant, String notice, String noticetime, String confirmor, String confirmtime, String omicsoriginalresultprovider, String omicsoriginalapplicationreceivedtime, String omicsanalysisresultprovider, String omicsapplicationreceivedtime, String phenotypicdataprovider, String phenotypicapplicationreceivedtime, String datadeliverytime, String datadeliverymethod, String deliverer, String deliverercontactinformation) {
        Applicant = applicant;
        Notice = notice;
        Noticetime = noticetime;
        Confirmor = confirmor;
        Confirmtime = confirmtime;
        Omicsoriginalresultprovider = omicsoriginalresultprovider;
        Omicsoriginalapplicationreceivedtime = omicsoriginalapplicationreceivedtime;
        Omicsanalysisresultprovider = omicsanalysisresultprovider;
        Omicsapplicationreceivedtime = omicsapplicationreceivedtime;
        Phenotypicdataprovider = phenotypicdataprovider;
        Phenotypicapplicationreceivedtime = phenotypicapplicationreceivedtime;
        Datadeliverytime = datadeliverytime;
        Datadeliverymethod = datadeliverymethod;
        Deliverer = deliverer;
        Deliverercontactinformation = deliverercontactinformation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Record record = (Record) o;
        return Objects.equals(Applicant, record.Applicant) &&
                Objects.equals(Notice, record.Notice) &&
                Objects.equals(Noticetime, record.Noticetime) &&
                Objects.equals(Confirmor, record.Confirmor) &&
                Objects.equals(Confirmtime, record.Confirmtime) &&
                Objects.equals(Omicsoriginalresultprovider, record.Omicsoriginalresultprovider) &&
                Objects.equals(Omicsoriginalapplicationreceivedtime, record.Omicsoriginalapplicationreceivedtime) &&
                Objects.equals(Omicsanalysisresultprovider, record.Omicsanalysisresultprovider) &&
                Objects.equals(Omicsapplicationreceivedtime, record.Omicsapplicationreceivedtime) &&
                Objects.equals(Phenotypicdataprovider, record.Phenotypicdataprovider) &&
                Objects.equals(Phenotypicapplicationreceivedtime, record.Phenotypicapplicationreceivedtime) &&
                Objects.equals(Datadeliverytime, record.Datadeliverytime) &&
                Objects.equals(Datadeliverymethod, record.Datadeliverymethod) &&
                Objects.equals(Deliverer, record.Deliverer) &&
                Objects.equals(Deliverercontactinformation, record.Deliverercontactinformation);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Applicant, Notice, Noticetime, Confirmor, Confirmtime, Omicsoriginalresultprovider, Omicsoriginalapplicationreceivedtime, Omicsanalysisresultprovider, Omicsapplicationreceivedtime, Phenotypicdataprovider, Phenotypicapplicationreceivedtime, Datadeliverytime, Datadeliverymethod, Deliverer, Deliverercontactinformation);
    }

    public String getApplicant() {
        return Applicant;
    }

    public void setApplicant(String applicant) {
        Applicant = applicant;
    }

    public String getNotice() {
        return Notice;
    }

    public void setNotice(String notice) {
        Notice = notice;
    }

    public String getNoticetime() {
        return Noticetime;
    }

    public void setNoticetime(String noticetime) {
        Noticetime = noticetime;
    }

    public String getConfirmor() {
        return Confirmor;
    }

    public void setConfirmor(String confirmor) {
        Confirmor = confirmor;
    }

    public String getConfirmtime() {
        return Confirmtime;
    }

    public void setConfirmtime(String confirmtime) {
        Confirmtime = confirmtime;
    }

    public String getOmicsoriginalresultprovider() {
        return Omicsoriginalresultprovider;
    }

    public void setOmicsoriginalresultprovider(String omicsoriginalresultprovider) {
        Omicsoriginalresultprovider = omicsoriginalresultprovider;
    }

    public String getOmicsoriginalapplicationreceivedtime() {
        return Omicsoriginalapplicationreceivedtime;
    }

    public void setOmicsoriginalapplicationreceivedtime(String omicsoriginalapplicationreceivedtime) {
        Omicsoriginalapplicationreceivedtime = omicsoriginalapplicationreceivedtime;
    }

    public String getOmicsanalysisresultprovider() {
        return Omicsanalysisresultprovider;
    }

    public void setOmicsanalysisresultprovider(String omicsanalysisresultprovider) {
        Omicsanalysisresultprovider = omicsanalysisresultprovider;
    }

    public String getOmicsapplicationreceivedtime() {
        return Omicsapplicationreceivedtime;
    }

    public void setOmicsapplicationreceivedtime(String omicsapplicationreceivedtime) {
        Omicsapplicationreceivedtime = omicsapplicationreceivedtime;
    }

    public String getPhenotypicdataprovider() {
        return Phenotypicdataprovider;
    }

    public void setPhenotypicdataprovider(String phenotypicdataprovider) {
        Phenotypicdataprovider = phenotypicdataprovider;
    }

    public String getPhenotypicapplicationreceivedtime() {
        return Phenotypicapplicationreceivedtime;
    }

    public void setPhenotypicapplicationreceivedtime(String phenotypicapplicationreceivedtime) {
        Phenotypicapplicationreceivedtime = phenotypicapplicationreceivedtime;
    }

    public String getDatadeliverytime() {
        return Datadeliverytime;
    }

    public void setDatadeliverytime(String datadeliverytime) {
        Datadeliverytime = datadeliverytime;
    }

    public String getDatadeliverymethod() {
        return Datadeliverymethod;
    }

    public void setDatadeliverymethod(String datadeliverymethod) {
        Datadeliverymethod = datadeliverymethod;
    }

    public String getDeliverer() {
        return Deliverer;
    }

    public void setDeliverer(String deliverer) {
        Deliverer = deliverer;
    }

    public String getDeliverercontactinformation() {
        return Deliverercontactinformation;
    }

    public void setDeliverercontactinformation(String deliverercontactinformation) {
        Deliverercontactinformation = deliverercontactinformation;
    }
}
