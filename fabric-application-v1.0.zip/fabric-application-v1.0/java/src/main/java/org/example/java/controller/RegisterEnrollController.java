package org.example.java.controller;

import org.example.java.user.RegisterEnrollUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RegisterEnrollController {
    @RequestMapping("/registerenroll")
    public String registerenroll(){
        return RegisterEnrollUser.Register();
    }
}
