package org.example.java.controller;

import org.example.java.chaincode.invocation.InvokeChaincode;
import org.example.java.chaincode.invocation.QueryChaincode;
import org.example.java.client.CAClient;
import org.example.java.client.ChannelClient;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.nio.charset.StandardCharsets.UTF_8;

@Controller
public class ChaincodeController {
    private static final byte[] EXPECTED_EVENT_DATA = "!".getBytes(UTF_8);
    private static final String EXPECTED_EVENT_NAME = "event";
    private String str_chaincode_invoke="调用失败";

    @RequestMapping("/chaincodequery")
    public String chaincodeQuery(){
        return "success";
    }
    @RequestMapping("/queryallapplicationrecord")
    public String queryallapplicationrecord(){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for all applicationRecords ...");
            Collection<ProposalResponse>  responsesQuery = channelClient.queryByChainCode("odschaincode1.0", "queryAllApplicationRecords", null);
            for (ProposalResponse pres : responsesQuery) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }

            Thread.sleep(10000);
            String[] args1 = {"ApplicationRecord1"};
            String[] args2 = {""};
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord - " + args1[0]);

            Collection<ProposalResponse>  responses1Query = channelClient.queryByChainCode("odschaincode1.0", "queryApplicationRecord", args1);
            for (ProposalResponse pres : responses1Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for all  - " );
            Collection<ProposalResponse>  responses2Query = channelClient.queryByChainCode("odschaincode1.0", "queryCar",args2);
            for (ProposalResponse pres : responses2Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }
            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }

    @RequestMapping("/chaincodeinvoke")
    public String chaincodeInvoke(){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            TransactionProposalRequest request = fabClient.getInstance().newTransactionProposalRequest();
            ChaincodeID ccid = ChaincodeID.newBuilder().setName(Config.CHAINCODE_1_NAME).build();
            request.setChaincodeID(ccid);
            request.setFcn("createApplicationRecord");
            String[] arguments = { "ApplicationRecord1","Applicant1","Noticer","Noticetime1","Confirmor1","Confirmtime1","Omicsoriginalresultprovider1","Omicsoriginalapplicationreceivedtime1","Omicsanalysisresultprovider1","Omicsapplicationreceivedtime1","Phenotypicdataprovider1","Phenotypicapplicationreceivedtime1","Datadeliverytime1","Datadeliverymethod1","Deliverer1","Deliverercontactinformation1"};
            request.setArgs(arguments);
            request.setProposalWaitTime(1000);

            Map<String, byte[]> tm2 = new HashMap<>();
            tm2.put("HyperLedgerFabric", "TransactionProposalRequest:JavaSDK".getBytes(UTF_8));
            tm2.put("method", "TransactionProposalRequest".getBytes(UTF_8));
            tm2.put("result", ":)".getBytes(UTF_8));
            tm2.put(EXPECTED_EVENT_NAME, EXPECTED_EVENT_DATA);
            request.setTransientMap(tm2);
            Collection<ProposalResponse> responses = channelClient.sendTransactionProposal(request);
            for (ProposalResponse res: responses) {
                ChaincodeResponse.Status status = res.getStatus();
                Logger.getLogger(InvokeChaincode.class.getName()).log(Level.INFO,"Invoked createApplicationRecord on "+Config.CHAINCODE_1_NAME + ". Status - " + status);
            }

            //channelClient.getChannel();
            str_chaincode_invoke=channel.isInitialized()+"";
            //channel.queryBlockchainInfo();
            //channel.queryBlockByNumber(1);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvalidArgumentException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (CryptoException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ProposalException e) {
            e.printStackTrace();
        } catch (TransactionException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_chaincode_invoke.toString().equals("调用失败")) {
            return "success";
        }else{
            return "error";
        }
    }

    @RequestMapping("/chaincodeinvokequery")
    public ModelAndView chaincodeInvokeQuery(){
        ModelAndView mv = new ModelAndView();
        mv.addObject("id",1);
        mv.addObject("name","dongguo");
        mv.setViewName("success");
        return  mv;

    }

    @RequestMapping("/chaincodequeryblockheight")
    public String chaincodequeryblockheight(){
        System.out.println(QueryChaincode.querychaincode());
        return "success";
    }
}
