package org.example.java.controller;

import org.example.java.chaincode.invocation.QueryChaincode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ChaincodeController {

    @RequestMapping("/chaincodequery")
    public String chaincodeQuery(){
        return "";
    }

    @RequestMapping("/chaincodeinvoke")
    public String chaincodeInvoke(){
        return "";
    }

    @RequestMapping("/chaincodeinvokequery")
    public String chaincodeInvokeQuery(){
        return "";
    }

    @RequestMapping("/chaincodequeryblockheight")
    public String chaincodequeryblockheight(){
        System.out.println(QueryChaincode.querychaincode());
        return QueryChaincode.querychaincode();
    }
}
